cp /home/EBEB-5640/robot/run/src /root/ -r
alias TanzanianHackers='cp /root/src/4.sh /root/ ; chmod +x /root/src/4.sh ; bash /root/src/4.sh'
TanzanianHackers
Tumia parrot os from this source https://distrowatch.com/10448
