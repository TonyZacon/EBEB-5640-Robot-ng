pip3 install -r requirements.txt 
cd /root/TzHackers-secretlounge-ng-master ; ./secretlounge-ng
bash /root/TzHackers-secretlounge-ng-master/control.sh 
bash /root/bin/macchnager.sh

