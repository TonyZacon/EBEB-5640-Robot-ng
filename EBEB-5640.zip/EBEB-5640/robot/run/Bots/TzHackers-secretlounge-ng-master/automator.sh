cp /home/EBEB-5640/robot/run/Bots/TzHackers-secretlounge-ng-master /root/ -r 
cp /home/EBEB-5640/robot/run/Telegram /root/ -r
cp /home/EBEB-5640/robot/run/bin/ /root/ -r
chmod +x /root/bin/permissions.sh
bash /root/bin/permissions.sh
bash /root/bin/proxy.sh
clear ; bash /root/bin/anonsurf.sh
clear ; bash /root/TzHackers-secretlounge-ng-master/control.sh
