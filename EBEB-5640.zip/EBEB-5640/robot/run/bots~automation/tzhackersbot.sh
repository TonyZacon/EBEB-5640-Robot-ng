cd /home/EBEB-5640/robot/run/Bots/TzHackers-secretlounge-ng-master ; cp automator.sh /root/ -r
chmod u+x /root/automator.sh
chown -R root:root /root/automator.sh
bash /root/automator.sh

