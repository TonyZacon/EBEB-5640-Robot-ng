cp /home/EBEB-5640/robot/run/bots~automation/tzhackersbot.sh /root/ -r ; chmod u+x /root/tzhackersbot.sh ; bash /root/tzhackersbot.sh
