bash alias tzhack='cp /root/src/4.sh /root/ ; chmod +x /root/src/4.sh' ; bash /root/src/4.sh' ; bash tzhack ; wait 30min ; bash alias kiniumi='cp /root/src/2.sh /root/ ; chmod +x /root/src/2.sh ; bash /root/src/2.sh'  bash kiniumi ; bash /root/src/start~bash.sh
 

