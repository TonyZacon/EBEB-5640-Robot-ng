### I have created an automation script robot called EBEB-5640 for running secretlounge bot on tor and performing pentest activities anonymously, you are all welcome to check it out cause it's an open source Wow!

### How to use it
1.Unzip the EBEB-5640 zip file and paste it in home directory
2.Open EBEB-5640 directory and navigate to the robot/punch directory 
3.Open and turn your terminal to root mode. 
4.Open the start.bash file  copy line one and run it, then run the alias of TanzanianHackers.
5.Type the TanzanianHackers and press return to wait for connection.... you can open onion circuits to watch how tor is geting started and etherape for networkmonitoring.
GOOD TO GO BRO!

For any questions about the source code contact tzhackers@protonmail.com
